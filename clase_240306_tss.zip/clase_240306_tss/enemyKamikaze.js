
const KamikazeState = {
    looking: 0,
    kamikaze: 1
}

class EnemyKamikaze extends Enemy {
    constructor(img, initialPosition, life) {
        super(img, initialPosition, life);

        this.state = KamikazeState.looking;

        this.lookingTime = 3;
        this.lookingTimeAux = 0;
        this.kamikazeSpeed = 500;
    }

    Update(deltaTime) {
        switch(this.state) {
            case KamikazeState.looking:
                // look for the player
                this.rotation = Math.atan2(
                    player.position.y - this.position.y,
                    player.position.x - this.position.x
                );

                this.lookingTimeAux += deltaTime;
                if (this.lookingTimeAux >= this.lookingTime) {
                    this.state = KamikazeState.kamikaze;
                    this.lookingTimeAux = 0;
                }
                break;
            case KamikazeState.kamikaze:
                // go forward
                this.position.x += Math.cos(this.rotation) * this.kamikazeSpeed * deltaTime;
                this.position.y += Math.sin(this.rotation) * this.kamikazeSpeed * deltaTime;

                // check scene bounds
                // left wall
                if (this.position.x < sceneLimits.x + this.boundingRadius) {
                    this.position.x = sceneLimits.x + this.boundingRadius;
                    this.state = KamikazeState.looking;
                }
                // right wall
                if (this.position.x > sceneLimits.x + sceneLimits.width - this.boundingRadius) {
                    this.position.x = sceneLimits.x + sceneLimits.width - this.boundingRadius;
                    this.state = KamikazeState.looking;
                }
                // top wall
                if (this.position.y > sceneLimits.y + sceneLimits.height - this.boundingRadius) {
                    this.position.y = sceneLimits.y + sceneLimits.height - this.boundingRadius;
                    this.state = KamikazeState.looking;
                }
                // down wall
                if (this.position.y < sceneLimits.y + this.boundingRadius) {
                    this.position.y = sceneLimits.y + this.boundingRadius;
                    this.state = KamikazeState.looking;
                }
                break;
        }
    }

}
